# Image Preview

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

## Features

This extension provides VS Code's built-in image preview functionality.

Supported image formats:

- `*.jpg`, `*.jpe`, `*.jpeg`
- `*.png`
- `*.bmp`
- `*.gif`
- `*.ico`
- `*.webp`
