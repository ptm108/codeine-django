# React Native Tutorial
This repo contains all the course files for the React Tutorial for Beginners playlist on The Net Ninja Playlist

## Using the course files
Each lesson in the series has its own branch, so you'll need to select that branch to see the coe for that lesson. E.g. to see the code for lesson 10, you would select the lesson-10 branch.

## Installing dependencies
If you download the repo code / clone the repo, you will need to run `npm install` in the project directory to install any project dependencies first. Without doing this, the code may not work as expected.

